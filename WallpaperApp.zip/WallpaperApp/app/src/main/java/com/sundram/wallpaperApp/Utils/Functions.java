package com.sundram.wallpaperApp.Utils;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

import com.sundram.wallpaperApp.R;

public class Functions {
    public static void changeMainFragment(FragmentActivity fragmentActivity, Fragment fragment) {

        fragmentActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .commit();
    }
}
